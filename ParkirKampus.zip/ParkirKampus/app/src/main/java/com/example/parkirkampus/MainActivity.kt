package com.example.parkirkampus

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import com.bumptech.glide.Glide
import com.example.parkirkampus.api.ApiConfig
import com.example.parkirkampus.auth.LoginActivity
import com.example.parkirkampus.databinding.ActivityMainBinding
import com.example.parkirkampus.response.UsersResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var userId: Int = -1
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        userId = getUserId()


        binding.imageMenu

        userId = intent.getIntExtra("id", -1)
        Log.d("MainActivity", "Value of userId: $userId")
        val name = intent.getStringExtra("name")
        val photo = intent.getStringExtra("photo")
        if (!photo.isNullOrEmpty()) {
            Glide.with(this)
                .load(photo)
                .into(binding.imageMenu)

            Log.d("GlideDebug", "Image URL: $photo")
        }

        binding.txtName.text = name ?: "User"


//        fetchUserData(userId)

        binding.parkingSlotsInfoPage.setOnClickListener {
            val intent = Intent(this@MainActivity, ParkingSlotActivity::class.java)
            startActivity(intent)
        }

        binding.attendancesPages.setOnClickListener {
            val intent = Intent(this@MainActivity, AttendancesActivity::class.java)
            startActivity(intent)
        }
    }

    private fun getUserId(): Int {
        sharedPreferences = getSharedPreferences("user_data", Context.MODE_PRIVATE)
        return sharedPreferences.getInt("id", -1)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.navbarmenuitem, menu)
        return  true
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.menuBio ->{
         ApiConfig.getService().getUsers(userId).enqueue(object : Callback<UsersResponse>{
             override fun onResponse(call: Call<UsersResponse>, response: Response<UsersResponse>) {
                 val userResponse = response.body()
                 if (userResponse != null && userResponse.results?.isNotEmpty() == true) {
                     val user = userResponse.results.find { it?.id == userId }
                     if (user != null) {
                         val userId = user.id
                         val userName = user.name ?: "User"
                         val userEmail = user.email ?: "Email"
                         val userPassword = user.password ?: "Password"
                         val userPhone = user.phone ?: "Phone"
                         val userPhoto = user.photo ?: ""
                         binding.txtName.text = userName
                         // Load userPhoto using Glide if available
                             val intent = Intent(this@MainActivity, ProfileActivity::class.java)
                             intent.putExtra("id",userId)
                             intent.putExtra("name", userName)
                             intent.putExtra("email", userEmail)
                            intent.putExtra("password", userPassword)
                             intent.putExtra("phone", userPhone)
                             intent.putExtra("photo", userPhoto)
                             startActivity(intent)
                         }
                     }
             }

             override fun onFailure(call: Call<UsersResponse>, t: Throwable) {
                 TODO("Not yet implemented")
             }

         })


            }
            R.id.menuLogout -> {
                val intent = Intent(this@MainActivity, LoginActivity::class.java)
                startActivity(intent)
                finish()
                Toast.makeText(this, "Logout berhasil",Toast.LENGTH_SHORT).show()
            }
        }
        return true
    }

//    private fun fetchUserData(userId: Int) {
//        Log.d("MainActivity", "Fetching user data for userId: $userId")
//        val call = ApiConfig.getService().getUsers(userId)
//        call.enqueue(object : Callback<UsersResponse> {
//            override fun onResponse(call: Call<UsersResponse>, response: Response<UsersResponse>) {
//                if (response.isSuccessful) {
//                    val userResponse = response.body()
//                    if (userResponse != null && userResponse.results?.isNotEmpty() == true) {
//                        val user = userResponse.results.find { it?.id == userId }
//                        if (user != null) {
//                            val userName = user.name ?: "User"
//                            val userEmail = user.email ?: "Email"
//                            val userPhone = user.phone ?: "Phone"
//                            val userPhoto = user.photo ?: ""
//
//                            binding.txtName.text = userName
//                            // Load userPhoto using Glide if available
//                        } else {
//                            Log.d("MainActivity", "User not found with userId: $userId")
//                        }
//                    } else {
//                        Log.d("MainActivity", "No user data found")
//                    }
//                } else {
//                    Log.d("MainActivity", "Failed to fetch user data")
//                }
//            }
//
//            override fun onFailure(call: Call<UsersResponse>, t: Throwable) {
//                Log.e("MainActivity", "Error fetching user data: ${t.message}")
//            }
//        })
//    }
}