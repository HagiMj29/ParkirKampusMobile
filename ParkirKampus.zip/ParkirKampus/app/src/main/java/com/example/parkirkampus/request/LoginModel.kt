package com.example.parkirkampus.request

data class LoginModel (
    val email : String,
    val password : String
        )
