package com.example.parkirkampus.api

import com.example.parkirkampus.request.LoginModel
import com.example.parkirkampus.request.ParkingActivitieModel
import com.example.parkirkampus.request.RegisterModel
import com.example.parkirkampus.request.UpdateProfileModel
import com.example.parkirkampus.response.AttendancesResponse
import com.example.parkirkampus.response.LoginResponse
import com.example.parkirkampus.response.ParkingSlotsResponse
import com.example.parkirkampus.response.UsersResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiServices {
    @POST("login")
    fun datalogin(@Body loginModel: LoginModel): Call<LoginResponse>

    @POST("register")
    fun dataRegister(@Body registerModel: RegisterModel): Call<RegisterModel>

    @GET("parkingslots")
    fun getParkingSlots(): Call<ParkingSlotsResponse>

    @GET("users")
    fun getUsers(@Query("id") userId: Int): Call<UsersResponse>

    @PUT("users/{user}")
    fun updateUserInfo(@Path("user") userId: String, @Body updateProfile: String): Call<UsersResponse>


    @GET("parkingattendances")
    fun getParkingAttendances(): Call<AttendancesResponse>

    @POST("parkingactivitie")
    fun getParkingActivitie(@Body parkingActivitieModel: ParkingActivitieModel): Call<ParkingActivitieModel>





}