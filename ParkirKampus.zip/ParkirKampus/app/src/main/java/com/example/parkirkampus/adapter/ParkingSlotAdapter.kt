package com.example.parkirkampus.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.parkirkampus.R
import com.example.parkirkampus.response.ResultsItem

class ParkingSlotAdapter(val dataSlot: List<ResultsItem?>?) : RecyclerView.Adapter<ParkingSlotAdapter.ViewHolder>() {
    class ViewHolder(view : View): RecyclerView.ViewHolder(view) {
        val txtSlot = view.findViewById<TextView>(R.id.idslot)
        val txtStatus = view.findViewById<TextView>(R.id.idstatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.rvparkingslot,parent,false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        if (dataSlot != null){
            return dataSlot.size
        }
        return  0
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.txtSlot.text = dataSlot?.get(position)?.slot
        holder.txtStatus.text = dataSlot?.get(position)?.status
    }
}