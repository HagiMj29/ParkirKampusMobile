package com.example.parkirkampus.request

import java.time.LocalDateTime

data class ParkingActivitieModel (
    val user_id : Int,
    val slot_id : Int,
    val vehicle_number : String,
    val vehicle_brand : String,
    val in_datetime : String,
    val out_datetime : String
        )
