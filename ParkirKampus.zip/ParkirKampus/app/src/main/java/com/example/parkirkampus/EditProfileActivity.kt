package com.example.parkirkampus

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.example.parkirkampus.api.ApiConfig
import com.example.parkirkampus.databinding.ActivityEditProfileBinding
import com.example.parkirkampus.request.UpdateProfileModel
import com.example.parkirkampus.response.UsersResponse
import com.google.gson.Gson
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class EditProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditProfileBinding
    private lateinit var sharedPreferences: SharedPreferences
    private var userId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        getUserId()
        val name = intent.getStringExtra("name")
        userId = intent.getIntExtra("id", -1).toString() // Mengubah Int menjadi String
        Log.d("ProfileActivity", "Value of userId: $userId")
        val email = intent.getStringExtra("email")
        val password = intent.getStringExtra("password")
        val phone = intent.getStringExtra("phone")
        val photo = intent.getStringExtra("photo")

        binding.txtEditName.setText(name)
        binding.txtEditEmail.setText(email)
        binding.txtEditPassword.setText(password)
        binding.txtEditPhone.setText(phone)

        binding.btnConfirmEdit.setOnClickListener {

                val txtNewName = binding.txtEditName.text.toString()
                val txtNewEmail = binding.txtEditEmail.text.toString()
                val txtNewPassword = binding.txtEditPassword.text.toString()
                val txtNewPhone = binding.txtEditPhone.text.toString()

                val updateProfileModel = UpdateProfileModel(txtNewName, txtNewEmail, txtNewPassword, txtNewPhone)
                val gson = Gson()
                val json = gson.toJson(updateProfileModel)
                Log.d("Testing", json)
                updateUserProfile(userId, json)
        }

    }
    private fun getUserId() {
        sharedPreferences = getSharedPreferences("user_data", Context.MODE_PRIVATE)
        userId = sharedPreferences.getInt("user_id", -1).toString()
    }
    private fun updateUserProfile(userId: String, updateProfileModel: String) {
        Log.d("EditProfileActivity", "Updating user profile: $updateProfileModel")
        val call = ApiConfig.getService().updateUserInfo(userId, updateProfileModel)
        call.enqueue(object : Callback<UsersResponse> {
            override fun onResponse(call: Call<UsersResponse>, response: Response<UsersResponse>) {
                if (response.isSuccessful) {
                    val json = Gson().toJson(response.body())
                    Log.d("EditProfileActivity", "JSON Response: $json")
                    val updatedUser = response.body()
                    Log.d("EditProfileActivity", "Response: ${response.body()}")
                    if (updatedUser != null) {
                        Log.d("EditProfileActivity", "JSON Response: $json")
                        Toast.makeText(
                            applicationContext,
                            "Profil berhasil diperbarui",
                            Toast.LENGTH_SHORT
                        ).show()
                        val intent = Intent(this@EditProfileActivity, ProfileActivity::class.java)
                        startActivity(intent)
                        finish()
                    } else {
                        Toast.makeText(
                            applicationContext,
                            "Gagal memperbarui profil",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }

            override fun onFailure(call: Call<UsersResponse>, t: Throwable) {
                Log.e("EditProfileActivity", "Error updating user profile: ${t.message}")
            }
        })
    }
}