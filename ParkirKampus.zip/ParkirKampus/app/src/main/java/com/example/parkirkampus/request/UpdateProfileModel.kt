package com.example.parkirkampus.request

data class UpdateProfileModel (
    val role: String? = null,
    val phone: String? = null,
    val name: String? = null,
    val password : String? = null,
    val id: Int? = null,
    val email: String? = null
        )
